
'use client';

import { useState } from 'react';
import Link from 'next/link';
import MembershipModal from '../../components/MembershipModal';

export default function AkilliEslestirmePage() {
  const [showMembershipModal, setShowMembershipModal] = useState(false);

  const features = [
    {
      icon: 'ri-brain-line',
      title: 'Yapay Zeka Desteği',
      description: 'Gelişmiş algoritmalar ile en uygun iş ortaklarını bulun',
      color: 'bg-[#1B365D]'
    },
    {
      icon: 'ri-search-2-line',
      title: 'Akıllı Arama',
      description: 'Sektör, konum ve ihtiyaçlarınıza göre filtreleme',
      color: 'bg-[#D4AF37]'
    },
    {
      icon: 'ri-team-line',
      title: 'Otomatik Eşleştirme',
      description: 'Uyumlu firmalarla otomatik olarak eşleşin',
      color: 'bg-[#1B365D]'
    },
    {
      icon: 'ri-time-line',
      title: 'Hızlı Sonuçlar',
      description: 'Dakikalar içinde doğru partnerleri keşfedin',
      color: 'bg-[#D4AF37]'
    }
  ];

  const steps = [
    {
      number: '1',
      title: 'Profil Oluşturun',
      description: 'Şirket bilgilerinizi ve iş birliği hedeflerinizi girin'
    },
    {
      number: '2',
      title: 'AI Analizi',
      description: 'Sistem sizin için en uygun partnerleri analiz eder'
    },
    {
      number: '3',
      title: 'Eşleşme',
      description: 'Uyumlu firmalarla bağlantı kurun ve iş birliği başlatın'
    }
  ];

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-[#1B365D] to-[#2A4A6B] text-white py-24">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Akıllı Eşleştirme Sistemi
              </h1>
              <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto">
                Yapay zeka destekli sistem ile sektörünüzde doğru iş ortaklarını bulun
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  onClick={() => setShowMembershipModal(true)}
                  className="bg-[#D4AF37] text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#B8941F] transition-colors whitespace-nowrap cursor-pointer"
                >
                  Hemen Başla
                </button>
                <Link
                  href="/kesfet"
                  className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-[#1B365D] transition-colors whitespace-nowrap cursor-pointer"
                >
                  Firmaları Keşfet
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Özellikler */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#1B365D] mb-4">
                Sistem Özellikleri
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Gelişmiş teknoloji ile iş ortaklıklarınızı güçlendirin
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <div key={index} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow text-center">
                  <div className={`w-16 h-16 ${feature.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <i className={`${feature.icon} w-8 h-8 flex items-center justify-center text-white`}></i>
                  </div>
                  <h3 className="text-xl font-bold text-[#1B365D] mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Nasıl Çalışır */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#1B365D] mb-4">
                Nasıl Çalışır?
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Üç basit adımda doğru iş ortaklarınızı bulun
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {steps.map((step, index) => (
                <div key={index} className="text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-[#1B365D] to-[#2A4A6B] rounded-full flex items-center justify-center mx-auto mb-6">
                    <span className="text-2xl font-bold text-white">{step.number}</span>
                  </div>
                  <h3 className="text-xl font-bold text-[#1B365D] mb-4">
                    {step.title}
                  </h3>
                  <p className="text-gray-600">
                    {step.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* İstatistikler */}
        <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#1B365D] mb-4">
                Platform Başarıları
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
                <div className="text-4xl font-bold text-[#D4AF37] mb-2">1000+</div>
                <div className="text-gray-600">Başarılı Eşleştirme</div>
              </div>
              <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
                <div className="text-4xl font-bold text-[#1B365D] mb-2">850+</div>
                <div className="text-gray-600">Aktif Firma</div>
              </div>
              <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
                <div className="text-4xl font-bold text-[#D4AF37] mb-2">%95</div>
                <div className="text-gray-600">Memnuniyet Oranı</div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-gradient-to-r from-[#1B365D] to-[#2A4A6B] text-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Hemen Başlayın
            </h2>
            <p className="text-xl mb-8 text-gray-200">
              Ücretsiz üye olun ve doğru iş ortaklarınızı keşfetmeye başlayın
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={() => setShowMembershipModal(true)}
                className="bg-[#D4AF37] text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#B8941F] transition-colors whitespace-nowrap cursor-pointer"
              >
                Ücretsiz Üye Ol
              </button>
              <Link
                href="/iletisim"
                className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-[#1B365D] transition-colors whitespace-nowrap cursor-pointer"
              >
                Bilgi Al
              </Link>
            </div>
          </div>
        </section>
      </div>

      <MembershipModal 
        isOpen={showMembershipModal} 
        onClose={() => setShowMembershipModal(false)} 
      />
    </>
  );
}
