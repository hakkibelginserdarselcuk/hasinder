'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function AkilliEslestirmePage() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const features = [
    {
      icon: 'ri-calendar-line',
      title: 'Sektörel Ajandalar',
      description: 'Ortak ilgi alanlarına göre filtrelenmiş takvim ve gündem entegrasyonu'
    },
    {
      icon: 'ri-map-pin-line',
      title: 'Coğrafi Yakınlık Analizi',
      description: 'Lokasyon tabanlı eşleştirme ile iş birliklerini yerel olarak güçlendirme'
    },
    {
      icon: 'ri-search-line',
      title: 'İş Ayrıntılarının Belirlenmesi',
      description: 'Hedef, kapasite, uzmanlık alanı gibi kriterlerle detaylı eşleştirme'
    },
    {
      icon: 'ri-robot-line',
      title: 'Otomatik Öneri',
      description: 'AI destekli algoritmalarla günlük partner önerileri'
    }
  ];

  const benefits = [
    'Sektörel hedeflerinize özel partner önerileri',
    'Zamandan tasarruf, daha isabetli bağlantılar',
    'Gelişmiş algoritmalarla yüksek uyumluluk'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-50">
      {/* Hero Section */}
      <section className="relative pt-24 pb-20 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-10"
          style={{
            backgroundImage: `url(https://readdy.ai/api/search-image?query=Modern%20AI-powered%20business%20networking%20platform%20with%20interconnected%20professionals%20on%20digital%20world%20map%2C%20bright%20futuristic%20interface%20showing%20business%20connections%20and%20partnerships%2C%20clean%20technological%20background%20with%20network%20nodes%20and%20data%20visualization%2C%20professional%20collaboration%20in%20digital%20environment&width=1920&height=1080&seq=ai-matching-hero&orientation=landscape)`
          }}
        />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className={`transform transition-all duration-1000 ${isVisible ? 'translate-x-0 opacity-100' : '-translate-x-10 opacity-0'}`}>
              <h1 className="text-4xl md:text-6xl font-bold text-[#1B365D] mb-6 leading-tight">
                Akıllı Eşleştirme Sistemi
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed">
                Yapay zeka destekli sistem ile sektörünüzde doğru iş ortaklarını bulun, güçlü gruplar kurun.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="#features"
                  className="bg-[#1B365D] text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#2C4F7C] hover:scale-105 hover:shadow-lg transition-all duration-300 whitespace-nowrap cursor-pointer inline-block text-center transform"
                >
                  Özellikleri Keşfet
                </Link>
                <Link
                  href="#start"
                  className="bg-transparent border-2 border-[#1B365D] text-[#1B365D] px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#1B365D] hover:text-white hover:scale-105 hover:shadow-lg transition-all duration-300 whitespace-nowrap cursor-pointer inline-block text-center transform"
                >
                  Hemen Başla
                </Link>
              </div>
            </div>

            <div className={`transform transition-all duration-1000 delay-300 ${isVisible ? 'translate-x-0 opacity-100' : 'translate-x-10 opacity-0'}`}>
              <img
                src="https://readdy.ai/api/search-image?query=AI%20matching%20system%20interface%20dashboard%20showing%20business%20partnership%20recommendations%2C%20modern%20clean%20UI%20with%20connection%20algorithms%20and%20network%20visualization%2C%20bright%20professional%20design%20with%20Turkish%20business%20professionals%20using%20smart%20matching%20technology%2C%20futuristic%20business%20collaboration%20platform&width=600&height=400&seq=ai-matching-dashboard&orientation=landscape"
                alt="Akıllı Eşleştirme Sistemi Dashboard"
                className="w-full h-auto rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1B365D] mb-4">
              Neden Akıllı Eşleştirme?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              İş ortaklıklarınızı yeni nesil teknoloji ile güçlendirin
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <div
                key={index}
                className={`bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8 text-center transform transition-all duration-700 hover:scale-105 hover:shadow-lg ${
                  isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                }`}
                style={{ transitionDelay: `${index * 200}ms` }}
              >
                <div className="w-16 h-16 bg-[#1B365D] rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="ri-check-line w-8 h-8 flex items-center justify-center text-white"></i>
                </div>
                <p className="text-lg font-semibold text-[#1B365D]">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1B365D] mb-4">
              Sistemin Özellikleri
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Gelişmiş yapay zeka algoritmaları ile donatılmış özelliklerimiz
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transform transition-all duration-700 hover:-translate-y-2 ${
                  isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                }`}
                style={{ transitionDelay: `${index * 300}ms` }}
              >
                <div className="flex items-start space-x-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#1B365D] to-[#2C4F7C] rounded-2xl flex items-center justify-center flex-shrink-0">
                    <i className={`${feature.icon} w-8 h-8 flex items-center justify-center text-white`}></i>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-[#1B365D] mb-4">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="start" className="py-20 bg-gradient-to-r from-[#1B365D] to-[#2C4F7C] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Hemen Başlayın
          </h2>
          <p className="text-xl mb-8 text-gray-200">
            Ücretsiz kaydolun, sektörünüzde en doğru bağlantıları kurun.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/giris"
              className="bg-[#D4AF37] text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#B8941F] hover:scale-105 hover:shadow-lg transition-all duration-300 whitespace-nowrap cursor-pointer inline-block text-center transform"
            >
              Hemen Eşleşmeye Başla
            </Link>
            <Link
              href="/kesfet"
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-[#1B365D] hover:scale-105 hover:shadow-lg transition-all duration-300 whitespace-nowrap cursor-pointer inline-block text-center transform"
            >
              Firmaları Keşfet
            </Link>
          </div>

          <div className="mt-12 bg-white/10 backdrop-blur-sm rounded-2xl p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-3xl font-bold text-[#D4AF37] mb-2">1000+</div>
                <div className="text-gray-200">Başarılı Eşleştirme</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#D4AF37] mb-2">850+</div>
                <div className="text-gray-200">Aktif Firma</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#D4AF37] mb-2">%95</div>
                <div className="text-gray-200">Memnuniyet Oranı</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1B365D] mb-4">
              Nasıl Çalışır?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Üç basit adımda doğru iş ortaklarınızı bulun
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-[#1B365D] to-[#2C4F7C] rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-bold text-[#1B365D] mb-4">Profil Oluşturun</h3>
              <p className="text-gray-600">
                Şirket bilgilerinizi ve iş birliği tercihlerinizi sisteme girin
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-[#D4AF37] to-[#B8941F] rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-bold text-[#1B365D] mb-4">AI Analizi</h3>
              <p className="text-gray-600">
                Yapay zeka sistemi sizin için en uygun partnerleri analiz eder
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-bold text-[#1B365D] mb-4">Bağlantı Kurun</h3>
              <p className="text-gray-600">
                Önerilen firmalarla iletişime geçin ve iş birliği başlatın
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}