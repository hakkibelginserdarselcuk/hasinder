
'use client';

import { useState } from 'react';

export default function BasindaBizPage() {
  const [selectedCategory, setSelectedCategory] = useState('tumu');

  const newsItems = [
    {
      id: 1,
      title: "Hatay İş Birliği Platformu 1000. Üyesine Ulaştı",
      excerpt: "Platform kurulduğu günden bu yana sürekli büyümeye devam ediyor ve artık 1000'den fazla aktif üyeye sahip.",
      date: "15 Mart 2024",
      category: "basarı",
      source: "Hatay Gündem",
      image: "https://readdy.ai/api/search-image?query=Successful%20business%20milestone%20celebration%20with%20entrepreneurs%20shaking%20hands%2C%20modern%20office%20setting%2C%20achievement%20atmosphere%2C%20professional%20team%20gathering&width=400&height=250&seq=news1&orientation=landscape",
      link: "#"
    },
    {
      id: 2,
      title: "Yeni Yatırım Fonundan 5 Milyon TL Destek",
      excerpt: "Hatay girişimcilerine yönelik özel yatırım fonu hayata geçirildi. İlk etapta 15 proje desteklenecek.",
      date: "12 Mart 2024",
      category: "yatirim",
      source: "Ekonomi Haber",
      image: "https://readdy.ai/api/search-image?query=Investment%20funding%20announcement%20with%20business%20documents%2C%20financial%20charts%2C%20professional%20meeting%20room%2C%20money%20and%20growth%20concept%20visualization&width=400&height=250&seq=news2&orientation=landscape",
      link: "#"
    },
    {
      id: 3,
      title: "Teknoloji Zirvesi'nde Hatay Standı Dikkat Çekti",
      excerpt: "İstanbul'da düzenlenenen teknoloji zirvesinde Hatay platformu büyük ilgi gördü ve yeni iş birlikleri kuruldu.",
      date: "8 Mart 2024",
      category: "etkinlik",
      source: "TechNews Türkiye",
      image: "https://readdy.ai/api/search-image?query=Technology%20summit%20exhibition%20booth%20with%20Hatay%20platform%20branding%2C%20visitors%20exploring%20innovative%20solutions%2C%20modern%20expo%20display%2C%20networking%20atmosphere&width=400&height=250&seq=news3&orientation=landscape",
      link: "#"
    },
    {
      id: 4,
      title: "Kadın Girişimcilere Özel Mentorluk Programı",
      excerpt: "Platform bünyesinde kadın girişimcileri destekleyen yeni mentorluk programı başlatıldı.",
      date: "5 Mart 2024",
      category: "program",
      source: "Kadın ve Kariyer",
      image: "https://readdy.ai/api/search-image?query=Women%20entrepreneurs%20mentorship%20program%20with%20professional%20women%20in%20business%20meeting%2C%20modern%20conference%20room%2C%20supportive%20atmosphere%2C%20career%20development&width=400&height=250&seq=news4&orientation=landscape",
      link: "#"
    },
    {
      id: 5,
      title: "Uluslararası İş Birliği Anlaşması İmzalandı",
      excerpt: "Avrupa'daki partner platformlarla iş birliği anlaşması imzalandı. Hatay girişimcileri artık global pazara açılacak.",
      date: "2 Mart 2024",
      category: "anlaşma",
      source: "İş Dünyası",
      image: "https://readdy.ai/api/search-image?query=International%20business%20agreement%20signing%20ceremony%20with%20officials%20from%20different%20countries%2C%20formal%20meeting%20room%2C%20handshake%20moment%2C%20global%20partnership&width=400&height=250&seq=news5&orientation=landscape",
      link: "#"
    },
    {
      id: 6,
      title: "Genç Girişimci Yarışması Sonuçlandı",
      excerpt: "18-25 yaş arası girişimcilere yönelik yarışmada kazananlar belli oldu. Ödüller 20 Mart'ta verilecek.",
      date: "28 Şubat 2024",
      category: "yarışma",
      source: "Gençlik ve Spor",
      image: "https://readdy.ai/api/search-image?query=Young%20entrepreneurs%20competition%20award%20ceremony%20with%20winners%20holding%20trophies%2C%20modern%20auditorium%2C%20celebration%20atmosphere%2C%20business%20achievement&width=400&height=250&seq=news6&orientation=landscape",
      link: "#"
    }
  ];

  const categories = [
    { id: 'tumu', name: 'Tümü' },
    { id: 'basarı', name: 'Başarı Hikayeleri' },
    { id: 'yatirim', name: 'Yatırım Haberleri' },
    { id: 'etkinlik', name: 'Etkinlikler' },
    { id: 'program', name: 'Programlar' },
    { id: 'anlaşma', name: 'Anlaşmalar' },
    { id: 'yarışma', name: 'Yarışmalar' }
  ];

  const filteredNews = selectedCategory === 'tumu' 
    ? newsItems 
    : newsItems.filter(item => item.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-[#1B365D] to-[#2C5F7D] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Basında Biz</h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Hatay İş Birliği Platformu'nun medyadaki yer aldığı haberler ve başarı hikayeleri
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-white rounded-xl p-6 text-center shadow-sm">
            <div className="text-3xl font-bold text-[#1B365D] mb-2">245</div>
            <div className="text-gray-600">Medya Haberi</div>
          </div>
          <div className="bg-white rounded-xl p-6 text-center shadow-sm">
            <div className="text-3xl font-bold text-[#D4AF37] mb-2">12</div>
            <div className="text-gray-600">TV Röportajı</div>
          </div>
          <div className="bg-white rounded-xl p-6 text-center shadow-sm">
            <div className="text-3xl font-bold text-green-600 mb-2">8</div>
            <div className="text-gray-600">Ödül</div>
          </div>
          <div className="bg-white rounded-xl p-6 text-center shadow-sm">
            <div className="text-3xl font-bold text-blue-600 mb-2">2.5M</div>
            <div className="text-gray-600">Medya Erişimi</div>
          </div>
        </div>

        {/* Category Filters */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap cursor-pointer transition-colors ${
                  selectedCategory === category.id
                    ? 'bg-[#1B365D] text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>

        {/* Featured News */}
        {filteredNews.length > 0 && (
          <div className="mb-12">
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="md:flex">
                <div className="md:w-1/2">
                  <img
                    src={filteredNews[0].image}
                    alt={filteredNews[0].title}
                    className="w-full h-64 md:h-full object-cover object-top"
                  />
                </div>
                <div className="md:w-1/2 p-8">
                  <div className="flex items-center mb-4">
                    <span className="bg-[#D4AF37] text-white px-3 py-1 rounded-full text-sm font-medium mr-3">
                      Öne Çıkan
                    </span>
                    <span className="text-gray-500 text-sm">{filteredNews[0].date}</span>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">{filteredNews[0].title}</h2>
                  <p className="text-gray-600 mb-6">{filteredNews[0].excerpt}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-[#1B365D] font-medium">{filteredNews[0].source}</span>
                    <button className="bg-[#1B365D] text-white px-6 py-2 rounded-lg hover:bg-[#2C5F7D] whitespace-nowrap cursor-pointer">
                      Haberi Oku
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredNews.slice(1).map((item) => (
            <div key={item.id} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-lg transition-shadow">
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-48 object-cover object-top"
              />
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[#1B365D] font-medium text-sm">{item.source}</span>
                  <span className="text-gray-500 text-sm">{item.date}</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3 line-clamp-2">{item.title}</h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3">{item.excerpt}</p>
                <button className="text-[#1B365D] hover:text-[#D4AF37] font-medium text-sm cursor-pointer">
                  Devamını Oku <i className="ri-arrow-right-line w-4 h-4 inline-flex items-center justify-center ml-1"></i>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Press Kit */}
        <div className="bg-white rounded-xl p-8 mt-16">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Basın Kiti</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Hatay İş Birliği Platformu hakkında detaylı bilgiler, görseller ve iletişim bilgileri
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 border border-gray-200 rounded-lg">
              <i className="ri-file-text-line w-12 h-12 flex items-center justify-center mx-auto mb-4 text-[#1B365D]"></i>
              <h4 className="font-semibold mb-2">Basın Açıklamaları</h4>
              <p className="text-gray-600 text-sm mb-4">Resmi açıklamalar ve duyurular</p>
              <button className="text-[#1B365D] hover:text-[#D4AF37] font-medium cursor-pointer">
                İndir
              </button>
            </div>
            
            <div className="text-center p-6 border border-gray-200 rounded-lg">
              <i className="ri-image-line w-12 h-12 flex items-center justify-center mx-auto mb-4 text-[#1B365D]"></i>
              <h4 className="font-semibold mb-2">Logo ve Görseller</h4>
              <p className="text-gray-600 text-sm mb-4">Yüksek çözünürlüklü logo ve fotoğraflar</p>
              <button className="text-[#1B365D] hover:text-[#D4AF37] font-medium cursor-pointer">
                İndir
              </button>
            </div>
            
            <div className="text-center p-6 border border-gray-200 rounded-lg">
              <i className="ri-contacts-line w-12 h-12 flex items-center justify-center mx-auto mb-4 text-[#1B365D]"></i>
              <h4 className="font-semibold mb-2">İletişim Bilgileri</h4>
              <p className="text-gray-600 text-sm mb-4">Basın sözcüleri ve iletişim</p>
              <button className="text-[#1B365D] hover:text-[#D4AF37] font-medium cursor-pointer">
                İletişim
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
