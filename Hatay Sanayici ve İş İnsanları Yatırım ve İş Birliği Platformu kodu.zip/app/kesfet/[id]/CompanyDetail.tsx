
'use client';

import { useState } from 'react';
import Link from 'next/link';
import Header from '../../../components/Header';
import Footer from '../../../components/Footer';
import ContactModal from './ContactModal';

const companies = [
  {
    id: 1,
    name: "AgroTech Tarım Teknolojileri",
    logo: "https://readdy.ai/api/search-image?query=modern%20agricultural%20technology%20company%20logo%20with%20green%20and%20blue%20colors%2C%20simple%20geometric%20design%2C%20professional%20corporate%20identity%2C%20clean%20white%20background%2C%20minimalist%20style&width=200&height=200&seq=agrotech-logo&orientation=squarish",
    heroImage: "https://readdy.ai/api/search-image?query=modern%20agricultural%20technology%20farm%20with%20IoT%20sensors%2C%20smart%20farming%20equipment%2C%20green%20fields%2C%20blue%20sky%2C%20professional%20photography%20style%2C%20high%20quality%20corporate%20image%2C%20technology%20innovation%20in%20agriculture&width=1200&height=400&seq=agrotech-hero&orientation=landscape",
    description: "AgroTech, tarım sektöründe teknoloji ile sürdürülebilirliği bir araya getiren öncü bir firmadır. IoT sensörler, akıllı sulama sistemleri ve veri analitiği ile çiftçilerin verimini artırıyor, kaynak kullanımını optimize ediyoruz.",
    sector: "Tarım",
    location: "İstanbul",
    foundedYear: "2019",
    employeeCount: "25-50",
    phone: "+90 212 555 0123",
    email: "info@agrotech.com.tr",
    website: "www.agrotech.com.tr",
    address: "Maslak Mahallesi, Teknoloji Caddesi No:15, Sarıyer/İstanbul",
    services: [
      "IoT Tarım Sensörleri",
      "Akıllı Sulama Sistemleri",
      "Tarımsal Veri Analizi",
      "Drone ile Tarla İzleme",
      "Sürdürülebilir Tarım Danışmanlığı"
    ],
    socialLinks: {
      linkedin: "https://linkedin.com/company/agrotech",
      twitter: "https://twitter.com/agrotech",
      instagram: "https://instagram.com/agrotech"
    },
    gallery: [
      "https://readdy.ai/api/search-image?query=smart%20agriculture%20IoT%20sensors%20in%20field%2C%20modern%20farming%20technology%2C%20green%20plants%2C%20professional%20product%20photography&width=400&height=300&seq=agrotech-1&orientation=landscape",
      "https://readdy.ai/api/search-image?query=automated%20irrigation%20system%20in%20greenhouse%2C%20smart%20farming%20equipment%2C%20water%20management%20technology%2C%20professional%20agricultural%20photography&width=400&height=300&seq=agrotech-2&orientation=landscape",
      "https://readdy.ai/api/search-image?query=agricultural%20drone%20flying%20over%20crops%2C%20precision%20farming%20technology%2C%20aerial%20view%20of%20farmland%2C%20modern%20agriculture%20innovation&width=400&height=300&seq=agrotech-3&orientation=landscape"
    ]
  },
  {
    id: 2,
    name: "SolarMax Enerji Çözümleri",
    logo: "https://readdy.ai/api/search-image?query=solar%20energy%20company%20logo%20with%20sun%20symbol%2C%20yellow%20and%20orange%20gradient%20colors%2C%20modern%20clean%20design%2C%20renewable%20energy%20theme%2C%20white%20background%2C%20professional%20corporate%20branding&width=200&height=200&seq=solarmax-logo&orientation=squarish",
    heroImage: "https://readdy.ai/api/search-image?query=solar%20panel%20installation%20on%20rooftop%2C%20renewable%20energy%20system%2C%20blue%20sky%2C%20professional%20photography%2C%20clean%20energy%20technology%2C%20sustainable%20power%20generation&width=1200&height=400&seq=solarmax-hero&orientation=landscape",
    description: "SolarMax, güneş enerjisi sektöründe 5 yıllık deneyimiyle Türkiye'nin önde gelen enerji çözümleri sağlayıcısıdır. Konut ve ticari projeler için tam entegre güneş enerjisi sistemleri sunuyoruz.",
    sector: "Enerji",
    location: "Ankara",
    foundedYear: "2018",
    employeeCount: "50-100",
    phone: "+90 312 555 0456",
    email: "bilgi@solarmax.com.tr",
    website: "www.solarmax.com.tr",
    address: "Çankaya Mahallesi, Enerji Bulvarı No:42, Çankaya/Ankara",
    services: [
      "Güneş Paneli Kurulumu",
      "Hibrit Enerji Sistemleri",
      "Enerji Depolama Çözümleri",
      "Elektrik Üretim Danışmanlığı",
      "Bakım ve Onarım Hizmetleri"
    ],
    socialLinks: {
      linkedin: "https://linkedin.com/company/solarmax",
      facebook: "https://facebook.com/solarmax",
      instagram: "https://instagram.com/solarmax"
    },
    gallery: [
      "https://readdy.ai/api/search-image?query=residential%20solar%20panel%20system%20on%20house%20roof%2C%20clean%20energy%20installation%2C%20professional%20photography%2C%20sustainable%20home%20energy&width=400&height=300&seq=solarmax-1&orientation=landscape",
      "https://readdy.ai/api/search-image?query=commercial%20solar%20farm%20with%20large%20panels%2C%20renewable%20energy%20facility%2C%20blue%20sky%2C%20industrial%20scale%20solar%20installation&width=400&height=300&seq=solarmax-2&orientation=landscape",
      "https://readdy.ai/api/search-image?query=solar%20energy%20storage%20battery%20system%2C%20modern%20energy%20technology%2C%20indoor%20installation%2C%20professional%20equipment%20photography&width=400&height=300&seq=solarmax-3&orientation=landscape"
    ]
  }
];

interface CompanyDetailProps {
  companyId: string;
}

export default function CompanyDetail({ companyId }: CompanyDetailProps) {
  const [showContactModal, setShowContactModal] = useState(false);
  const [activeTab, setActiveTab] = useState('hakkinda');

  const company = companies.find(c => c.id === parseInt(companyId));

  if (!company) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="pt-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Firma Bulunamadı</h1>
            <Link
              href="/kesfet"
              className="text-[#1B365D] hover:text-[#D4AF37] font-medium cursor-pointer"
            >
              Firmaları Keşfet sayfasına dön
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative h-96 overflow-hidden">
          <img
            src={company.heroImage}
            alt={company.name}
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-black/40"></div>
          <div className="absolute inset-0 flex items-center">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
              <div className="flex items-center space-x-6">
                <img
                  src={company.logo}
                  alt={`${company.name} logo`}
                  className="w-24 h-24 rounded-xl bg-white p-2 object-cover"
                />
                <div>
                  <h1 className="text-4xl font-bold text-white mb-2">
                    {company.name}
                  </h1>
                  <div className="flex items-center space-x-4 text-white/90">
                    <span className="bg-[#D4AF37] px-3 py-1 rounded-full text-sm font-medium">
                      {company.sector}
                    </span>
                    <div className="flex items-center">
                      <i className="ri-map-pin-line w-4 h-4 flex items-center justify-center mr-1"></i>
                      {company.location}
                    </div>
                    <div className="flex items-center">
                      <i className="ri-calendar-line w-4 h-4 flex items-center justify-center mr-1"></i>
                      {company.foundedYear} kuruluş
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Navigation Tabs */}
        <section className="bg-white shadow-sm border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <nav className="flex space-x-8">
              <button
                onClick={() => setActiveTab('hakkinda')}
                className={`py-4 px-1 border-b-2 font-medium text-sm cursor-pointer ${
                  activeTab === 'hakkinda'
                    ? 'border-[#1B365D] text-[#1B365D]'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Hakkında
              </button>
              <button
                onClick={() => setActiveTab('hizmetler')}
                className={`py-4 px-1 border-b-2 font-medium text-sm cursor-pointer ${
                  activeTab === 'hizmetler'
                    ? 'border-[#1B365D] text-[#1B365D]'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Hizmetler
              </button>
              <button
                onClick={() => setActiveTab('galeri')}
                className={`py-4 px-1 border-b-2 font-medium text-sm cursor-pointer ${
                  activeTab === 'galeri'
                    ? 'border-[#1B365D] text-[#1B365D]'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Galeri
              </button>
              <button
                onClick={() => setActiveTab('iletisim')}
                className={`py-4 px-1 border-b-2 font-medium text-sm cursor-pointer ${
                  activeTab === 'iletisim'
                    ? 'border-[#1B365D] text-[#1B365D]'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                İletişim
              </button>
            </nav>
          </div>
        </section>

        {/* Content */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="lg:col-span-2">
                {activeTab === 'hakkinda' && (
                  <div className="bg-white rounded-xl shadow-sm p-8">
                    <h2 className="text-2xl font-bold text-gray-900 mb-6">Firma Hakkında</h2>
                    <p className="text-gray-600 leading-relaxed mb-6">
                      {company.description}
                    </p>
                    
                    <div className="grid grid-cols-2 gap-6 pt-6 border-t border-gray-100">
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-2">Kuruluş Yılı</h3>
                        <p className="text-gray-600">{company.foundedYear}</p>
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-2">Çalışan Sayısı</h3>
                        <p className="text-gray-600">{company.employeeCount}</p>
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-2">Sektör</h3>
                        <p className="text-gray-600">{company.sector}</p>
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-2">Konum</h3>
                        <p className="text-gray-600">{company.location}</p>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'hizmetler' && (
                  <div className="bg-white rounded-xl shadow-sm p-8">
                    <h2 className="text-2xl font-bold text-gray-900 mb-6">Hizmetlerimiz</h2>
                    <div className="grid grid-cols-1 gap-4">
                      {company.services.map((service, index) => (
                        <div key={index} className="flex items-center p-4 bg-gray-50 rounded-lg">
                          <i className="ri-check-line w-5 h-5 flex items-center justify-center text-green-600 mr-3"></i>
                          <span className="text-gray-800 font-medium">{service}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'galeri' && (
                  <div className="bg-white rounded-xl shadow-sm p-8">
                    <h2 className="text-2xl font-bold text-gray-900 mb-6">Galeri</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {company.gallery.map((image, index) => (
                        <div key={index} className="rounded-lg overflow-hidden">
                          <img
                            src={image}
                            alt={`${company.name} galeri ${index + 1}`}
                            className="w-full h-48 object-cover object-top hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'iletisim' && (
                  <div className="bg-white rounded-xl shadow-sm p-8">
                    <h2 className="text-2xl font-bold text-gray-900 mb-6">İletişim Bilgileri</h2>
                    <div className="space-y-4">
                      <div className="flex items-center">
                        <i className="ri-phone-line w-5 h-5 flex items-center justify-center text-gray-400 mr-3"></i>
                        <span className="text-gray-800">{company.phone}</span>
                      </div>
                      <div className="flex items-center">
                        <i className="ri-mail-line w-5 h-5 flex items-center justify-center text-gray-400 mr-3"></i>
                        <span className="text-gray-800">{company.email}</span>
                      </div>
                      <div className="flex items-center">
                        <i className="ri-global-line w-5 h-5 flex items-center justify-center text-gray-400 mr-3"></i>
                        <a
                          href={`https://${company.website}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[#1B365D] hover:text-[#D4AF37] cursor-pointer"
                        >
                          {company.website}
                        </a>
                      </div>
                      <div className="flex items-start">
                        <i className="ri-map-pin-line w-5 h-5 flex items-center justify-center text-gray-400 mr-3 mt-1"></i>
                        <span className="text-gray-800">{company.address}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Contact Card */}
                <div className="bg-white rounded-xl shadow-sm p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">İletişime Geç</h3>
                  <button
                    onClick={() => setShowContactModal(true)}
                    className="w-full bg-[#1B365D] text-white py-3 rounded-lg hover:bg-[#2E5984] transition-colors font-medium mb-3 cursor-pointer"
                  >
                    Mesaj Gönder
                  </button>
                  <a
                    href={`tel:${company.phone}`}
                    className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors font-medium flex items-center justify-center cursor-pointer"
                  >
                    <i className="ri-phone-line w-4 h-4 flex items-center justify-center mr-2"></i>
                    Ara
                  </a>
                </div>

                {/* Social Links */}
                <div className="bg-white rounded-xl shadow-sm p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Sosyal Medya</h3>
                  <div className="flex space-x-3">
                    {company.socialLinks.linkedin && (
                      <a
                        href={company.socialLinks.linkedin}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-10 h-10 flex items-center justify-center bg-[#0077B5] text-white rounded-lg hover:opacity-80 transition-opacity cursor-pointer"
                      >
                        <i className="ri-linkedin-fill w-5 h-5 flex items-center justify-center"></i>
                      </a>
                    )}
                    {company.socialLinks.twitter && (
                      <a
                        href={company.socialLinks.twitter}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-10 h-10 flex items-center justify-center bg-[#1DA1F2] text-white rounded-lg hover:opacity-80 transition-opacity cursor-pointer"
                      >
                        <i className="ri-twitter-fill w-5 h-5 flex items-center justify-center"></i>
                      </a>
                    )}
                    {company.socialLinks.instagram && (
                      <a
                        href={company.socialLinks.instagram}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-10 h-10 flex items-center justify-center bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:opacity-80 transition-opacity cursor-pointer"
                      >
                        <i className="ri-instagram-fill w-5 h-5 flex items-center justify-center"></i>
                      </a>
                    )}
                    {company.socialLinks.facebook && (
                      <a
                        href={company.socialLinks.facebook}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-10 h-10 flex items-center justify-center bg-[#4267B2] text-white rounded-lg hover:opacity-80 transition-opacity cursor-pointer"
                      >
                        <i className="ri-facebook-fill w-5 h-5 flex items-center justify-center"></i>
                      </a>
                    )}
                  </div>
                </div>

                {/* Back to List */}
                <Link
                  href="/kesfet"
                  className="block bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-4 rounded-lg transition-colors font-medium text-center cursor-pointer"
                >
                  <i className="ri-arrow-left-line w-4 h-4 flex items-center justify-center mr-2 inline-flex"></i>
                  Firmalara Geri Dön
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Contact Modal */}
      <ContactModal
        isOpen={showContactModal}
        onClose={() => setShowContactModal(false)}
        company={company}
      />
    </div>
  );
}
