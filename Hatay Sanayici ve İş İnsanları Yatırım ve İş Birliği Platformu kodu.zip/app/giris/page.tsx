'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function GirisPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({
    email: '',
    password: '',
    general: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear errors when user starts typing
    if (errors[name as keyof typeof errors]) {
      setErrors(prev => ({
        ...prev,
        [name]: '',
        general: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {
      email: '',
      password: '',
      general: ''
    };

    // Email validation
    if (!formData.email) {
      newErrors.email = 'E-posta adresi gereklidir';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Geçerli bir e-posta adresi girin';
    }

    // Password validation
    if (!formData.password) {
      newErrors.password = 'Şifre gereklidir';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Şifre en az 6 karakter olmalıdır';
    }

    setErrors(newErrors);
    return !newErrors.email && !newErrors.password;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    setErrors(prev => ({ ...prev, general: '' }));
    
    try {
      // Form data for backend submission
      const loginData = new URLSearchParams();
      loginData.append('email', formData.email);
      loginData.append('password', formData.password);
      loginData.append('rememberMe', formData.rememberMe.toString());
      loginData.append('loginAttempt', 'true');

      // Submit to backend
      const response = await fetch('https://readdy.ai/api/form/user-login-system', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: loginData.toString()
      });

      // Simulate authentication logic
      if (formData.email && formData.password) {
        // Store user session data
        const userData = {
          email: formData.email,
          loginTime: new Date().toISOString(),
          rememberMe: formData.rememberMe
        };

        // Store in localStorage or sessionStorage based on remember me
        if (formData.rememberMe) {
          localStorage.setItem('userSession', JSON.stringify(userData));
        } else {
          sessionStorage.setItem('userSession', JSON.stringify(userData));
        }

        // Set authentication cookie/token simulation
        document.cookie = `auth-token=user-${Date.now()}; path=/; max-age=${formData.rememberMe ? 30 * 24 * 60 * 60 : 24 * 60 * 60}`;

        // Success notification
        const successMessage = 'Giriş başarılı! Ana sayfaya yönlendiriliyorsunuz...';
        
        // Show success state
        setFormData({
          email: '',
          password: '',
          rememberMe: false
        });

        // Redirect after short delay
        setTimeout(() => {
          router.push('/');
        }, 1500);

        // Show success feedback
        setErrors(prev => ({ ...prev, general: 'success' }));

      } else {
        throw new Error('Invalid credentials');
      }

    } catch (error) {
      setErrors(prev => ({
        ...prev,
        general: 'E-posta veya şifre hatalı. Lütfen bilgilerinizi kontrol edin.'
      }));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialLogin = (provider: string) => {
    setIsLoading(true);
    
    // Simulate social login
    setTimeout(() => {
      const userData = {
        email: `user@${provider}.com`,
        provider: provider,
        loginTime: new Date().toISOString(),
        rememberMe: true
      };
      
      localStorage.setItem('userSession', JSON.stringify(userData));
      document.cookie = `auth-token=${provider}-${Date.now()}; path=/; max-age=${30 * 24 * 60 * 60}`;
      
      router.push('/');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          {/* Header */}
          <div className="text-center">
            <div className="text-3xl font-bold text-[#1B365D] mb-2" style={{fontFamily: 'Pacifico, serif'}}>
              logo
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Üye Girişi</h2>
            <p className="text-gray-600">
              Hesabınıza giriş yaparak platformun tüm özelliklerinden yararlanın
            </p>
          </div>

          {/* Login Form */}
          <div className="bg-white rounded-xl shadow-sm p-8">
            <form id="user-login-form" onSubmit={handleSubmit} className="space-y-6">
              {/* General Error/Success Message */}
              {errors.general && errors.general !== 'success' && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">
                  <div className="flex items-center">
                    <i className="ri-error-warning-line w-4 h-4 flex items-center justify-center mr-2"></i>
                    {errors.general}
                  </div>
                </div>
              )}

              {errors.general === 'success' && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-green-700 text-sm">
                  <div className="flex items-center">
                    <i className="ri-check-line w-4 h-4 flex items-center justify-center mr-2"></i>
                    Giriş başarılı! Yönlendiriliyorsunuz...
                  </div>
                </div>
              )}

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  E-posta Adresi *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-[#1B365D] focus:border-transparent ${
                    errors.email ? 'border-red-300 bg-red-50' : 'border-gray-300'
                  }`}
                  placeholder="ornek@email.com"
                  disabled={isLoading}
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-600 flex items-center">
                    <i className="ri-error-warning-line w-3 h-3 flex items-center justify-center mr-1"></i>
                    {errors.email}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                  Şifre *
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    required
                    className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-[#1B365D] focus:border-transparent pr-12 ${
                      errors.password ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                    placeholder="Şifrenizi girin"
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 cursor-pointer"
                    disabled={isLoading}
                  >
                    <i className={`${showPassword ? 'ri-eye-off-line' : 'ri-eye-line'} w-5 h-5 flex items-center justify-center`}></i>
                  </button>
                </div>
                {errors.password && (
                  <p className="mt-1 text-sm text-red-600 flex items-center">
                    <i className="ri-error-warning-line w-3 h-3 flex items-center justify-center mr-1"></i>
                    {errors.password}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="rememberMe"
                    name="rememberMe"
                    checked={formData.rememberMe}
                    onChange={handleInputChange}
                    className="h-4 w-4 text-[#1B365D] focus:ring-[#1B365D] border-gray-300 rounded cursor-pointer"
                    disabled={isLoading}
                  />
                  <label htmlFor="rememberMe" className="ml-2 block text-sm text-gray-700 cursor-pointer">
                    Beni hatırla (30 gün)
                  </label>
                </div>
                <Link href="/sifremi-unuttum" className="text-sm text-[#1B365D] hover:text-[#D4AF37] cursor-pointer">
                  Şifremi unuttum
                </Link>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#1B365D] text-white py-3 px-4 rounded-lg hover:bg-[#2C5F7D] font-medium whitespace-nowrap cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isLoading ? (
                  <>
                    <i className="ri-loader-4-line w-5 h-5 flex items-center justify-center mr-2 animate-spin"></i>
                    Giriş yapılıyor...
                  </>
                ) : (
                  <>
                    <i className="ri-login-circle-line w-5 h-5 flex items-center justify-center mr-2"></i>
                    Güvenli Giriş Yap
                  </>
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="mt-6">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">veya</span>
                </div>
              </div>
            </div>

            {/* Social Login */}
            <div className="mt-6 space-y-3">
              <button 
                onClick={() => handleSocialLogin('google')}
                disabled={isLoading}
                className="w-full flex items-center justify-center px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 whitespace-nowrap cursor-pointer disabled:opacity-50"
              >
                <i className="ri-google-fill w-5 h-5 flex items-center justify-center mr-3 text-red-500"></i>
                Google ile Hızlı Giriş
              </button>
              <button 
                onClick={() => handleSocialLogin('linkedin')}
                disabled={isLoading}
                className="w-full flex items-center justify-center px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 whitespace-nowrap cursor-pointer disabled:opacity-50"
              >
                <i className="ri-linkedin-fill w-5 h-5 flex items-center justify-center mr-3 text-blue-600"></i>
                LinkedIn ile Hızlı Giriş
              </button>
            </div>
          </div>

          {/* Sign Up Link */}
          <div className="text-center">
            <p className="text-gray-600">
              Hesabınız yok mu?{' '}
              <Link href="/kayit-ol" className="text-[#1B365D] hover:text-[#D4AF37] font-medium cursor-pointer">
                Hemen üye olun
              </Link>
            </p>
          </div>

          {/* Security Info */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center mb-3">
              <i className="ri-shield-check-line w-5 h-5 flex items-center justify-center mr-2 text-green-600"></i>
              <h3 className="text-lg font-semibold text-gray-900">Güvenli Giriş</h3>
            </div>
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center">
                <i className="ri-check-line w-4 h-4 flex items-center justify-center mr-2 text-green-500"></i>
                256-bit SSL şifreleme ile korumalı
              </div>
              <div className="flex items-center">
                <i className="ri-check-line w-4 h-4 flex items-center justify-center mr-2 text-green-500"></i>
                Kişisel verileriniz güvende
              </div>
              <div className="flex items-center">
                <i className="ri-check-line w-4 h-4 flex items-center justify-center mr-2 text-green-500"></i>
                KVKK uyumlu veri işleme
              </div>
            </div>
          </div>

          {/* Benefits */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Üyelik Avantajları</h3>
            <div className="space-y-3">
              <div className="flex items-center text-sm text-gray-600">
                <i className="ri-vip-crown-line w-4 h-4 flex items-center justify-center mr-3 text-[#D4AF37]"></i>
                Yatırımcılar ve girişimcilerle doğrudan iletişim
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <i className="ri-calendar-event-line w-4 h-4 flex items-center justify-center mr-3 text-[#D4AF37]"></i>
                Özel etkinlik davetleri ve networking fırsatları
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <i className="ri-handshake-line w-4 h-4 flex items-center justify-center mr-3 text-[#D4AF37]"></i>
                İş birliği projelerine öncelikli erişim
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <i className="ri-graduation-cap-line w-4 h-4 flex items-center justify-center mr-3 text-[#D4AF37]"></i>
                Mentorluk ve danışmanlık hizmetleri
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}